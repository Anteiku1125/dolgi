# Home Works
* LOGGER [README](https://github.com/sslinNn/hw/tree/master/logger#readme)
* Emergency architecture [README](https://github.com/sslinNn/hw/blob/master/emergency/README.md)
* Banking <a href="https://github.com/sslinNn/hw/tree/master/banking">SERVICE</a>
